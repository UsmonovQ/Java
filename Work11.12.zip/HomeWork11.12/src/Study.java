public class Study {
    public static void main(String[] args) {
        //Задание 2. Создайте строку через new - I study Basic Java!
        //Напишите метод, который принимает в качестве параметра строку, передайте в этот метод созданную строку
        //Распечатать последний символ строки. Используем метод String.charAt().
        //Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        //Заменить все символы “а” на “о”.
        //Преобразуйте строку к верхнему регистру.
        //Преобразуйте строку к нижнему регистру.
        //Вырезать строку Java c помощью метода String.substring().
        String myStr = new String("I study Basic Java!");
        String(myStr);
    }
    public static void String(String myStr) {
        System.out.println("Sozdannaya Stroka: " + myStr);
        int quantity = myStr.length();
        if (quantity > 0) {
            int length = myStr.length();
            char simvol = myStr.charAt(length - 1);
            System.out.println("Posledniy simvol: " + simvol);
        }
        if (myStr.contains("Java")){
            System.out.println("Da eto stroka imeet slovo 'Java':");
        }
        String replece = myStr.replace('a','o');
        System.out.println(replece);
        String upper = myStr.toUpperCase();
        System.out.println(upper);
        String lower = myStr.toLowerCase();
        System.out.println(lower);
        String cut = myStr.substring(myStr.indexOf("Java"));
        System.out.println(cut);
    }
}