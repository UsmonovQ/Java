import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //: Задание 1. Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
        //Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.
        //Например: ввод - mama, papa. Вывод – mapa
        Scanner scr = new Scanner(System.in);
        System.out.println("Vedite  pervoe slovo: ");
        String str = scr.nextLine();
        System.out.println("Vedite vtorroe  slovo: ");
        String str1 = scr.nextLine();
        int num = str.length();
        int num1 = str1.length();
        System.out.println("V slove " + str + " imeetsya "  + num + " bukv:");
        System.out.println("V slove " + str1 + " imeetsya " + num1 + " bukv:");
        String word = str.substring(0, str.length()/2);
        String word1 = str1.substring(str1.length()/2);
        System.out.println(word + word1);
    }
}