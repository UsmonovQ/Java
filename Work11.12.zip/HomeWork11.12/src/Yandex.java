public class Yandex {
    public static void main(String[] args) {
        //Задание 3. Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
        // Если буква одна, то цифра не ставится.
        String str = "AAAABBBCCCDDEG";
        System.out.println("Nasha stroka: " + str);
        System.out.println("Nasha stroka svernuto: " + myString(str));
    }
    public static String myString(String str1) {
        StringBuilder st = new StringBuilder();
        int num = 1;
        for (int i = 1; i < str1.length(); i++) {
            if (str1.charAt(i) == str1.charAt(i - 1)) {
                num++;
            } else {
                st.append(str1.charAt(i - 1));
                if (num > 1) {
                    st.append(num);
                }
                num = 1;
            }
        }
        st.append(str1.length() - 1);
        if (num > 1) {
            st.append(num);
        }
        return st.toString();
    }
}

